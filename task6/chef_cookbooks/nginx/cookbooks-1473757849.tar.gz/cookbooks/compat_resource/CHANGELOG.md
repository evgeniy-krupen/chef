# compat_resource Cookbook CHANGELOG
This file is used to list changes made in each version of the compat_resource cookbook.

## 12.14.2 (2016-09-09)

- Improve documentation
- keep ChefCompat::Resource defined even if we don't load

## 12.14.1 (2016-09-07)

- add yum_repository resource from Chef 12.14
- Update the minimum chef version in the metadata to 12.1
- Added maintainers files
- suppress constant redef warnings when running chefspec

